%Project Title: Alzheimer Detection
%Author: TARUN
%Contact: tarun.techme@gmail.com 

the main purpose of this project is to detect Alzheimer by using MRI of patient take image mri and then detect ALZHEIMER AFFECTED patient.

steps to run code...............
1. run matlab code..........
2. you will get graphical user interface..........
3. load image.... filter....edge detection....detect button provided their to detect alzheimer.

this project is under processing
I am trying my best to develop as soon as possible.
 
thankyou 
